#include<func.h>

void print()
{
	printf("I am a printf\n");
}
