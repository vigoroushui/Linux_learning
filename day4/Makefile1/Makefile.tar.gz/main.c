#include<func.h>

void print();
int main()
{
	printf("I am a main\n");
	print();
	return 0;
}
