#include <func.h>
void print();
int sum(int,int);
int main()
{
    printf("I am main\n");
    print();
    print();
    sum(5,6);
    return 0;
}

