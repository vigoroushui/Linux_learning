#include <func.h>

void print()
{
    printf("I am print\n");
    return;
}

