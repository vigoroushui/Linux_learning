#include <func.h>

int main()
{
    printf("I am main2\n");
    return 0;
}

