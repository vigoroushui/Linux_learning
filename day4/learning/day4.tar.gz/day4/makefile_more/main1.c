#include <func.h>

int main()
{
    printf("I am main1\n");
    return 0;
}

